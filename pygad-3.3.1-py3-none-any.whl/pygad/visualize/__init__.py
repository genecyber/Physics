from pygad.visualize import plot

__version__ = "1.1.0"