from pygad.utils import parent_selection
from pygad.utils import crossover
from pygad.utils import mutation
from pygad.utils import nsga2

__version__ = "1.1.1"